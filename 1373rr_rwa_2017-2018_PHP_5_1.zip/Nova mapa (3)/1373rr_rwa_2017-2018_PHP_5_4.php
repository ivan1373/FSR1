<!doctype html>
<html>
    <head>
        <title>4. zadatak</title>
    </head>
    <body>
    	<?php
    		function aritm($a,$b)
            {
                echo ($a+$b)/2;
            }
            
            
            aritm(100,500);
           ?>

    </body>
</html>