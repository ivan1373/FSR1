﻿<!DOCTYPE html>
<html>
    <head>
        <title>3. zadatak</title>
    </head>
    <body>
    	<?php 
    	function check_jmbg($n)
            {
                //var n = document.querySelector("input").value;
                
               // $broj = n.toString();
                $dan = intval(substr($n, -13,2));
                $mjesec = intval(substr($n, -11,2));
                $god = intval(substr($n, -9,3));
                $region = intval(substr($n, -6,2));
                $j_br = intval(substr($n, -4,3));
                
                
                $A = intval(substr($n, -13,1));
                $B = intval(substr($n, -12,1));
                $V = intval(substr($n, -11,1));
                $G = intval(substr($n, -10,1));
                $D = intval(substr($n, -9,1));
                $Đ = intval(substr($n, -8,1));
                $E = intval(substr($n, -7,1));
                $Ž = intval(substr($n, -6,1));
                $Z = intval(substr($n, -5,1));
                $I = intval(substr($n, -4,1));
                $J = intval(substr($n, -3,1));
                $K = intval(substr($n, -2,1));
                
                
                if(strlen($n)!=13)
                    echo "Ne odgovara duljina JMBG, što znači da je neispravan";
                else{
                    $l = 11 - (( 7*($A+$E) + 6*($B+$Ž) + 5*($V+$Z) + 4*($G+$I) + 3*($D+$J) + 2*($Đ+$K) ) % 11);
                    if(($l==intval($n[12])) && ($dan<=32) && ($mjesec<=12) && ($god>=900))
                        {
                            echo "JMBG je ispravan.<br><br>";
                            echo "Datum rođenja je: ".$dan.".0".$mjesec.".1".$god.".<br>";
                            
                            
                            if($region < 10)
                                echo "Stranac u SFRJ <br>";
                            else if($region < 20 && $region >= 10)
                                echo "Bosna i Hercegovina <br>";
                            else if($region < 30 && $region >= 20)
                                echo "Crna Gora <br>";
                            else if($region < 40 && $region >= 30)
                                echo "Hrvatska <br>";
                            else if($region < 50 && $region >= 40)
                                echo "Makedonija <br>";
                            else if($region < 60 && $region >= 50)
                                echo "Slovenija <br>";
                            else if($region < 70 && $region >= 60)
                                echo "Nije korištena oznaka regije(iz neobjašnjenih razloga) <br>";
                            else if($region < 80 && $region >= 70)
                                echo "Centralna Srbija <br>";
                            else if($region < 90 && $region >= 80)
                                echo "AP Vojvodina <br>";
                            else if($region < 100 && $region >= 90)
                                echo "AP Kosovo i Metohija <br>";
                            else
                                echo "...<br>";
                            
                            if($j_br<500)
                                echo "Spol: M";
                            else
                                echo "Spol: Ž";
                            
                        }
                    else
                        echo "JMBG je neispravan jer kontrolna znamenka nije ispravna.";
                }
                
            }
            //check_jmbg("2306996152730");
              check_jmbg("1506957151633");
            ?>
    </body>
</html>