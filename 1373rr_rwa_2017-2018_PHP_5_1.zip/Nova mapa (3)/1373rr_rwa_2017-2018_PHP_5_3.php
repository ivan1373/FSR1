<!doctype html>
<html>
    <head>
        <title>3. zadatak</title>
    </head>
    <body>     
        
        <h1><strong>Table of Factorials</strong></h1>
        <br>
        <br>
<?php
	function fakt($n)
	{
		for($i=1;$i<=$n;$i++)
                    {
                        $rez = $i;
                        for($j=$i-1;$j>=1;$j--)
                        $rez *= $j;
                        
                        echo $i."! = ".($rez);
                        echo "<br>";
                    }
	}


	fakt(9);

?>
    </body>
</html>